$(function () {
    'use strict'
    var siteRoot;

    var lstIteration = [];
    function format(d,rows) {
        //debugger;
        
        var tableheader = '<div class="table-responsive"><table class="table">' +
            '<thead>' +
            '<th></th>' +
            '<th>User Story</th>' +
            '<th>Description</th>' +
            '<th>Points</th>' +
            '</thead><tbody>';
        for (var i = 0; i < rows.length; i++) {
            var row = '<tr><td></td><td><Strong>' + rows[i].userStoryNumber + '</Strong></td><td>' + rows[i].userStoryName + '</td><td>' + rows[i].planEstimate+'</td></tr>';
            tableheader = tableheader + row;
            row = "";
        }
        tableheader = tableheader +'</tbody></table></div>'
        return tableheader;
       
    }

    function setPredictabilityAndSprintLoadchart(predictability, sprintPercentage) {
        if (predictability <= 0 || predictability== null)
            predictability = 0;
        if (sprintPercentage <= 0 || sprintPercentage== null)
        sprintPercentage = 0;

        selectGauge3.set(predictability);
        selectGauge4.set(sprintPercentage);
        $("#divPredictability").text(predictability + '%');
        $("#divSprintLoad").text(sprintPercentage + '%');
    }

    function LoadoneSprintLookahead(oneSprintLookahead) {
     //   debugger;
        $('#oneSprintChart').remove();
        $('#onesprintahead').append('<canvas width="150" height="70" id="oneSprintChart"></canvas>');
       
            var datapi = {
                labels: ["Needs Definition", "Defined"],
                datasets: [
                    {
                        fill: true,
                        backgroundColor: [
                            '#ffc107',
                            '#3bb001'],
                        data: oneSprintLookahead,//[response.sprintLookAhead[0].needDefintionCount, response.sprintLookAhead[0].definedCount],
                        borderColor: ['white', 'white'],
                        borderWidth: [1, 1]
                    }
                ]
            }
        
       
        var optionspi = {
            title: {
                display: false,
                position: 'top'
            },
            legend: {
                display: true,
                position: 'bottom'
            },
            rotation: -0.7 * Math.PI
        };
        var ctxpi = document.getElementById("oneSprintChart").getContext('2d');
        var myBarChart = new Chart(ctxpi, {
            type: 'pie',
            data: datapi,
            options: optionspi
        });

        if (oneSprintLookahead[0] == 0 && oneSprintLookahead[1] == 0)
            document.getElementById("onesprintahead").hidden = true;
           
        else
            document.getElementById("onesprintahead").hidden = false;
    }
    
    function averageStoryPoints(userStorylabels, userStorydata, averageStorydata) {
        //debugger;
        $('#avgStoryChart').remove();
        $('#AverageStoryPoint').append('<canvas width="150" height="70" id="avgStoryChart"></canvas>');
        var ctx = document.getElementById("avgStoryChart").getContext('2d');
        var config = {
            type: 'line',
            data: {
                //labels:userstorylabels,
                labels: userStorylabels,//['TEST', '2020.PI2.S1', 'TEST2'],
                datasets: [{
                    label: 'Userstories',
                    backgroundColor: '#ffc107',
                    borderColor: '#ffc107',
                    data: userStorydata,
                    fill: false,
                    pointRadius: 10,
                    pointHoverRadius: 15,
                    showLine: false // no line shown
                },
                {
                    label: 'Average Story Point',
                    backgroundColor: '#3bb001',
                    borderColor: '#3bb001',
                    data: averageStorydata,
                    fill: false,
                    pointRadius: 10,
                    pointHoverRadius: 15,
                    showLine: false // no line shown
                }]
            },
            options: {
                responsive: true,
                title: {
                    display: true,
                },
                legend: {
                    display: true,
                    position: 'bottom'
                },
                elements: {
                    point: {
                        pointStyle: 'circle'
                    }
                },
                scales: {
                    xAxes: [{
                        gridLines: {
                            color: "rgba(0, 0, 0, 0)",
                            offsetGridLines: true
                        }
                    }],
                    yAxes: [{

                        gridLines: {
                            color: "rgba(0, 0, 0, 0)",
                        },
                        ticks: {
                            display: false,
                            stepSize: 4,
                            beginAtZero: true
                        }
                    }]
                }
            }
        };
        var myBarChart2 = new Chart(ctx, config);

        if (userStorylabels!=null && userStorydata!=null && averageStorydata!=null)
            document.getElementById('AverageStoryPoint').hidden = false
        else
            document.getElementById('AverageStoryPoint').hidden = true;
    }

    function riskTableBind(risks) {
       // debugger;
        if (risks != null || risks != undefined) {
            var table = $('#SubProgram_Risk');
             table.find("tbody tr").remove();
            for (var i = 0; i < risks.length; i++) {
                var row = '<tr>' +
                    '<td><strong class="text-danger">' + risks[i].comment + '</strong></td>' +
                    '</tr>'
                $('#SubProgram_Risk tbody').append(row);
            }
            document.getElementById('RisksDetails').hidden = false;
        }

        else
            document.getElementById('RisksDetails').hidden = true;
    }
    function riskbyserverity(labels, datasets, RiskPercentage) {
    

        $('#chartDonut').remove(); // this is my <canvas> element
        if (labels[0] !='') 
            document.getElementById('riskwholeid').hidden = false;
            
       
           
        $('#cdonutdiv').append('<canvas width="165px!important" height="96px!important" id="chartDonut"></canvas>');

        if (labels != null && datasets != null) {
            var datapie = {
                labels: labels,
                datasets: [{
                    data: datasets,
                    backgroundColor: ['#dc3545', '#3bb001', '#FFBF00']
                }]
            };

            var optionpie = {
                maintainAspectRatio: false,
                responsive: true,
                legend: {
                    display: false,
                },
                animation: {
                    animateScale: true,
                    animateRotate: true
                }
            };

            // For a doughnut chart
          
            var ctxpie = document.getElementById('chartDonut');
            var myPieChart6 = new Chart(ctxpie, {
                type: 'doughnut',
                data: datapie,
                options: optionpie
            });
            //if (labels[0] == undefined) {
            //    $('#risklegends').empty();
                
            //}
            $('#risklegends').empty();
            if (RiskPercentage != null&& labels[0]!='') {
              
                for (var i = 0; i < labels.length; i++) {
                    var row = '<div class="az-traffic-detail-item">' +
                        '<div>' +
                        '<span>' + labels[i] + '</span>' +
                        '<span>' + datasets[i] + '<span> (' + RiskPercentage[i] + '%)</span></span>' +
                        '</div >';
                    if (labels[i].toLowerCase() == 'high') {
                        row = row + '<div class="progress">' +
                            '<div class="progress-bar bg-danger wd-40p" role="progressbar" aria-valuenow=' + RiskPercentage[i] + ' aria-valuemin="0" aria-valuemax="100"></div>'
                        '</div>';
                    }
                    else if (labels[i].toLowerCase() == 'medium') {
                        row = row + '<div class="progress">' +
                            '<div class="progress-bar bg-warning wd-20p" role="progressbar" aria-valuenow=' + RiskPercentage[i] + ' aria-valuemin="0" aria-valuemax="100"></div>'
                        '</div>';
                    }
                    else if (labels[i].toLowerCase() == 'low') {
                        row = row + '<div class="progress">' +
                            '<div class="progress-bar bg-success wd-10p" role="progressbar" aria-valuenow=' + RiskPercentage[i] + ' aria-valuemin="0" aria-valuemax="100"></div>'
                        '</div>';
                    }
                    '</div>'
                    $('#risklegends').append(row);
                }
            } 
        }
       
        if (labels[0] == '') {
            $('#risklegends').empty();
           // $('#riskwholeid').hide();
             document.getElementById('riskwholeid').hidden = true;
        }
        else
             document.getElementById('riskwholeid').hidden = false;
          
    }

    $(document).ready(function () {
       // $("#msg").hide();
       
      var table = $('#example').DataTable({
            "aaSorting": [],
            "searching": false,
            "paging": false,
            "info": false,
            "columnDefs": [
                { "orderable": false, "targets": 0 },
                { "orderable": false, "targets": 5 },
            ]
        });
        //$('#msgbtn').on('click' ,function () {
        //    $("#msg").hide();
        //});

        // Add event listener for opening and closing details
        $('#example tbody').on('click', 'td.details-control', function () {
           // debugger;
            var tr = $(this).closest('tr');
            var sprintName = tr.find("td:eq(1)").text();
            var sprintbyrows = $.grep(lstIteration, function (v) {
                return v.iterationName === sprintName;
            });
        
            var row = table.row(tr);
            if (row.child.isShown()) {
                // This row is already open - close it
                row.child.hide();
                tr.removeClass('shown');
            }
            else {
                // Open this row
                row.child(format(row.data(),sprintbyrows)).show();
                tr.addClass('shown');
            }
           
        });
    });

    var selectGauge3 = new Gauge(document.getElementById("select-3"));
    var opts = {
        angle: -0.15,
        lineWidth: 0.15,
        radiusScale: 1,
        pointer: {
            length: 0.6,
            strokeWidth: 0.05,
            color: '#000000'
        },
        staticZones: [
            { strokeStyle: "#dc3545", min: 0, max: 20 },
            { strokeStyle: "#ffc107", min: 20, max: 60 },
            { strokeStyle: "#3bb001", min: 60, max: 100 },
        ],
        staticLabels: {
            font: "10px sans-serif",  // Specifies font
            labels: [0, 20, 60, 100],  // Print labels at these values
            color: "#000000",  // Optional: Label text color
            fractionDigits: 0  // Optional: Numerical precision. 0=round off.
        },
        limitMax: false,
        limitMin: false,
        strokeColor: '#E0E0E0',
        highDpiSupport: true
    };
    selectGauge3.minValue = 0;
    selectGauge3.maxValue = 100;
    selectGauge3.setOptions(opts);
    selectGauge3.set(0);
    $("#divPredictability").text('0 %')

    var selectGauge4 = new Gauge(document.getElementById("select-4"));
    selectGauge4.minValue = 0;
    selectGauge4.maxValue = 100;
    selectGauge4.setOptions(opts);
    selectGauge4.set(0);
    $("#divSprintLoad").text('0 %')

    var defaultvalueforOnesprint=[0,0]
    LoadoneSprintLookahead(defaultvalueforOnesprint);
    averageStoryPoints(null, null, null);
    riskTableBind(null);
    riskbyserverity(['','',''], [0, 0, 0], [0,0,0]);
    
   

    $('.select2').select2({
        placeholder: 'Select Project'
    });

   

    $('#EpicDetailId').on('change', function () {
      //  debugger;
        $('#epictxt').value = $("#EpicDetailId option:selected").text();
         var obj = {
             EpicId: this.value,
             ReleaseId: $("#ReleaseId").val(),
          
        };
        var re = new RegExp(/^.*\//);
     //alert(re.exec(window.location.href))
        $.ajax({
            url: re.exec(window.location.href) + "Program/GetEpicWiseInformation",
            type: 'GET',
            data: obj,
            success: function (response) {
              // debugger;
                if (response != null) {
                    lstIteration = response.storyTrends;
                    //  alert(lstIteration.length);

                    setPredictabilityAndSprintLoadchart(response.predictability, response.sprintPercentage)
                    var onesprintlookahead = [];
                    if (response.sprintLookAhead != null) {
                        $.each(response.sprintLookAhead, function (i, value) {
                            onesprintlookahead.push(value.needDefintionCount)
                            onesprintlookahead.push(value.definedCount)
                        })
                    }
                    else {
                        onesprintlookahead = [0, 0];
                    }
                    LoadoneSprintLookahead(onesprintlookahead);

                    var userStorylabels = [];
                    var userStorydata = [];
                    var averageStorydata = [];
                    if (response.averageStoryPoints != null) {
                        $.each(response.averageStoryPoints, function (i, value) {
                            userStorylabels.push(value.iterationName);
                            averageStorydata.push(value.avgStoryPoint)
                            userStorydata.push(value.storyCount)
                        });
                       
                    }
                    averageStoryPoints(userStorylabels, userStorydata, averageStorydata);
                    riskTableBind(response.risks);
                    var table = $('#example').DataTable();
                    table.clear().draw();
                    if (response.lstIteration != null) {
                       
                        for (var i = 0; i < response.lstIteration.length; i++) {
                            var row = '<tr>' +
                                '<td class="details-control"></td>' +
                                '<td><strong>' + response.lstIteration[i].iterationName + '</strong></td>' +
                                '<td>' + (new Date(response.lstIteration[i].iterationStartDate).getMonth() + 1) + '/' + (new Date(response.lstIteration[i].iterationStartDate).getDate()) + "--" + (new Date(response.lstIteration[i].iterationEndDate).getMonth() + 1) + '/' + (new Date(response.lstIteration[i].iterationEndDate).getDate()) + '</td>' +
                                '<td></td>' + '<td>' + response.lstIteration[i].completedVelocity + '</td>' +
                                '<td>' +
                                '<div class="progress">' +
                                '<div class="progress-bar bg-success" role="progressbar" style="width:20%">' +
                                '</div>' +
                                '<div class="progress-bar bg-warning" role="progressbar" style="width:50%">' +
                                '</div>' +
                                '<div class="progress-bar bg-danger" role="progressbar" style="width:20%">' +
                                '</div>' +
                                '</div>' + '<div>' + response.lstIteration[i].velocityPercentage.toFixed(2) + '</div>' + '</td>' + '</tr>'


                            table.row.add($(row)).draw();

                            // alert(response.lstIteration[i].iterationName);
                        }
                    }
                    //$('#example').DataTable();
                    console.log(response.data);
                    var RiskLabels = [];
                    var RiskCount = [];
                    var RiskPercentage = [];
                    if (response.riskSeverities != null) {
                        $.each(response.riskSeverities, function (i, value) {
                            RiskLabels.push(value.statusName);
                            RiskCount.push(value.actualCount);
                            RiskPercentage.push(value.percentage);
                        });
                       riskbyserverity(RiskLabels, RiskCount, RiskPercentage);
                    }
                   
                    
                }
                else {
                    alert("No Data found");
                   // $("#msg").show();
                     var table = $('#example');
                    table.find("tbody tr").remove();
                    setPredictabilityAndSprintLoadchart(0, 0)//reset chart
                    LoadoneSprintLookahead([0, 0])
                    averageStoryPoints(null, null, null);
                    riskTableBind(null);
                    riskbyserverity(['','',''], [0,0,0],[0,0,0]);

                }

               // alert(userStorylabels);
            },
            error: function (response) {
               // debugger;
                console.log("error");
                console.log(response.data);
            }
        });
        //alert(response);
    });

});