$(function () {
    'use strict'
    var lstIteration = [];
    function format(d,rows) {
        //return '<div class="table-responsive"><table class="table">' +
        //    '<thead>' +
        //    '<th></th>' +
        //    '<th>User Story</th>' +
        //    '<th>Description</th>' +
        //    '<th>Points</th>' +
        //    '</thead><tbody>' +
        //    '<tr><td></td><td><Strong>US56799</Strong></td><td>Windows Server Installation</td><td>3</td></tr>' +
        //    '</tbody></table></div>';

        var tableheader = '<div class="table-responsive"><table class="table">' +
            '<thead>' +
            '<th></th>' +
            '<th>User Story</th>' +
            '<th>Description</th>' +
            '<th>Points</th>' +
            '</thead><tbody>';
        for (var i = 0; i < rows.length; i++) {
            var row = '<tr><td></td><td><Strong>' + rows[i].userStoryNumber + '</Strong></td><td>' + rows[i].userStoryName + '</td><td>' + rows[i].planEstimate + '</td></tr>';
            tableheader = tableheader + row;
            row = "";
        }
        tableheader = tableheader + '</tbody></table></div>'
        return tableheader;

    }
    function setPredictabilityAndSprintLoadchart(predictability, sprintPercentage) {
        if (predictability <= 0 || predictability == null)
            predictability = 0;
        if (sprintPercentage <= 0 || sprintPercentage == null)
            sprintPercentage = 0;

        selectGauge3.set(predictability);
        selectGauge4.set(sprintPercentage);
        $("#divPredictability").text(predictability + '%');
        $("#divSprintLoad").text(sprintPercentage + '%');
    }
    function LoadoneSprintLookahead(oneSprintLookahead) {
        //debugger;
        $('#oneSprintChart').remove(); // this is my <canvas> element
        $('#oscdiv').append('<canvas width="150" height="70" id="oneSprintChart"></canvas>');
        
         var datapi = {
            labels: ["Needs Definition", "Defined"],
            datasets: [
                {
                    fill: true,
                    backgroundColor: [
                        '#ffc107',
                        '#3bb001'],
                    data: oneSprintLookahead,//[response.sprintLookAhead[0].needDefintionCount, response.sprintLookAhead[0].definedCount],
                    borderColor: ['white', 'white'],
                    borderWidth: [1, 1]
                }
            ]
        }
       

        var optionspi = {
            title: {
                display: false,
                position: 'top'
            },
            legend: {
                display: true,
                position: 'bottom'
            },
            rotation: -0.7 * Math.PI
        };
        var ctxpi = document.getElementById("oneSprintChart").getContext('2d');
        var myBarChart = new Chart(ctxpi, {
            type: 'pie',
            data: datapi,
            options: optionspi
        });

        if (oneSprintLookahead==null && oneSprintLookahead==null) {
            document.getElementById("onesprintahead").hidden = true;
            document.getElementById("burnchartId").hidden = true;
        }

        else {
            document.getElementById("onesprintahead").hidden = false;
            document.getElementById("burnchartId").hidden = false;
        }
    }
    function averageStoryPoints(userStorylabels, userStorydata, averageStorydata) {
         //debugger;
        $('#avgStoryChart').remove(); // this is my <canvas> element
        $('#spChartdiv').append('<canvas width="150" height="70" id="avgStoryChart"></canvas>');
        var ctx = document.getElementById("avgStoryChart").getContext('2d');
        var config = {
            type: 'line',
            data: {
                //labels:userstorylabels,
                labels: userStorylabels,//['TEST', '2020.PI2.S1', 'TEST2'],
                datasets: [{
                    label: 'Userstories',
                    backgroundColor: '#ffc107',
                    borderColor: '#ffc107',
                    data: userStorydata,
                    fill: false,
                    pointRadius: 10,
                    pointHoverRadius: 15,
                    showLine: false // no line shown
                },
                {
                    label: 'Average Story Point',
                    backgroundColor: '#3bb001',
                    borderColor: '#3bb001',
                    data: averageStorydata,
                    fill: false,
                    pointRadius: 10,
                    pointHoverRadius: 15,
                    showLine: false // no line shown
                }]
            },
            options: {
                responsive: true,
                title: {
                    display: true,
                },
                legend: {
                    display: true,
                    position: 'bottom'
                },
                elements: {
                    point: {
                        pointStyle: 'circle'
                    }
                },
                scales: {
                    xAxes: [{
                        gridLines: {
                            color: "rgba(0, 0, 0, 0)",
                            offsetGridLines: true
                        }
                    }],
                    yAxes: [{

                        gridLines: {
                            color: "rgba(0, 0, 0, 0)",
                        },
                        ticks: {
                            display: false,
                            stepSize: 4,
                            beginAtZero: true
                        }
                    }]
                }
            }
        };
        var myBarChart2 = new Chart(ctx, config);

        if (userStorylabels != null && userStorydata != null && averageStorydata != null)
            document.getElementById('AverageStoryPoint').hidden = false
        else
            document.getElementById('AverageStoryPoint').hidden = true;
    }
    function Burndownchart(labels, points) {
       // debugger;
        $('#burnChart').remove(); 
        $('#bchart').append('<canvas width="150" height="80" id="burnChart"></canvas>');

        var canvas = document.getElementById('burnChart');
        var data1 = {
            labels: ["0", "2", "4", "6", "8", "10"],
            datasets: [
                {
                    label: "Accepted",
                    backgroundColor: "#3bb001",
                    borderColor: "#3bb001",
                    borderWidth: 2,
                    hoverBackgroundColor: "#3bb001",
                    hoverBorderColor: "#3bb001",
                    data: points,
                }
            ]
        };
        var option1 = {
            animation: {
                duration: 5000
            }
        };

        var myBarChart2 = Chart.Bar(canvas, {
            data: data1,
            options: option1
        });

        if (points == null) 
                document.getElementById('burnchartId').hidden = true;
            
        else
                document.getElementById('burnchartId').hidden = false;
}
    $(document).ready(function () {
        var table = $('#example').DataTable({
            "aaSorting": [],
            "searching": false,
            "paging": false,
            "info": false,
            "columnDefs": [
                { "orderable": false, "targets": 0 },
                { "orderable": false, "targets": 5 },
            ]
        });

        // Add event listener for opening and closing details
        $('#example tbody').on('click', 'td.details-control', function () {
            var tr = $(this).closest('tr');
            var row = table.row(tr);

            var sprintName = tr.find("td:eq(1)").text();
            var sprintbyrows = $.grep(lstIteration, function (v) {
                return v.iterationName === sprintName;
            });

            if (row.child.isShown()) {
                // This row is already open - close it
                row.child.hide();
                tr.removeClass('shown');
            }
            else {
                // Open this row
              //  row.child(format(row.data())).show();
                row.child(format(row.data(),sprintbyrows)).show();
                tr.addClass('shown');
            }
        });
    });

    var selectGauge3 = new Gauge(document.getElementById("select-3"));
    var opts = {
        angle: -0.15,
        lineWidth: 0.15,
        radiusScale: 1,
        pointer: {
            length: 0.6,
            strokeWidth: 0.05,
            color: '#000000'
        },
        staticZones: [
            { strokeStyle: "#dc3545", min: 0, max: 20 },
            { strokeStyle: "#ffc107", min: 20, max: 60 },
            { strokeStyle: "#3bb001", min: 60, max: 100 },
        ],
        staticLabels: {
            font: "10px sans-serif",  // Specifies font
            labels: [0, 20, 60, 100],  // Print labels at these values
            color: "#000000",  // Optional: Label text color
            fractionDigits: 0  // Optional: Numerical precision. 0=round off.
        },
        limitMax: false,
        limitMin: false,
        strokeColor: '#E0E0E0',
        highDpiSupport: true
    };
    selectGauge3.minValue = 0;
    selectGauge3.maxValue = 100;
    selectGauge3.setOptions(opts);
    selectGauge3.set(0);
    $("#divPredictability").text('0 %')

    var selectGauge4 = new Gauge(document.getElementById("select-4"));
    selectGauge4.minValue = 0;
    selectGauge4.maxValue = 100;
    selectGauge4.setOptions(opts);
    selectGauge4.set(0);
    $("#divSprintLoad").text('0 %')

   LoadoneSprintLookahead(null);
   averageStoryPoints(null, null, null);
    Burndownchart(null, null);

    
   // document.getElementById("burnchartId").hidden = true;

    $('#teamId').on('change', function () {
     //   debugger;
     //   $('#epictxt').value = $("#EpicDetailId option:selected").text();
        var obj = {
            TeamId: this.value,
            ReleaseId: $("#ReleaseId").val()

        };
        var re = new RegExp(/^.*\//);
       // alert(re.exec(window.location.href))
        $.ajax({
            url: re.exec(window.location.href) + "Team/TeamWiseInformation",
            type: 'GET',
            data: obj,
            success: function (response) {
                //debugger;
                if (response != null) {
                    lstIteration = response.storyTrends
                    setPredictabilityAndSprintLoadchart(response.predictability, response.sprintPercentage)
                    if (response.lstIteration != null) {
                        var table = $('#example').DataTable();
                        table.clear().draw();
                        var table = $('#example').DataTable();
                        for (var i = 0; i < response.lstIteration.length; i++) {
                            var row = '<tr>' +
                                '<td class="details-control"></td>' +
                                '<td><strong>' + response.lstIteration[i].iterationName + '</strong></td>' +
                                '<td>' + (new Date(response.lstIteration[i].iterationStartDate).getMonth() + 1) + '/' + (new Date(response.lstIteration[i].iterationStartDate).getDate()) + "--" + (new Date(response.lstIteration[i].iterationEndDate).getMonth() + 1) + '/' + (new Date(response.lstIteration[i].iterationEndDate).getDate())  + '</td>' +
                                '<td></td>' + '<td>' + response.lstIteration[i].completedVelocity + '</td>' +
                                '<td>' +
                                '<div class="progress">' +
                                '<div class="progress-bar bg-success" role="progressbar" style="width:20%">' +
                                '</div>' +
                                '<div class="progress-bar bg-warning" role="progressbar" style="width:50%">' +
                                '</div>' +
                                '<div class="progress-bar bg-danger" role="progressbar" style="width:20%">' +
                                '</div>' +
                                '</div>' + '<div>' + response.lstIteration[i].velocityPercentage.toFixed(2)+'</div>' + '</td>' + '</tr>'


                            table.row.add($(row)).draw();
                           // $('#example tbody').append(row)
                            // alert(response.lstIteration[i].iterationName);
                        }
                    }

                    var onesprintlookahead = [];
                    if (response.sprintLookAhead != null) {
                        $.each(response.sprintLookAhead, function (i, value) {
                            onesprintlookahead.push(value.needDefintionCount)
                            onesprintlookahead.push(value.definedCount)
                        })
                    }
                    else {

                        onesprintlookahead = [0, 0];
                    }
                    LoadoneSprintLookahead(onesprintlookahead);


                    var userStorylabels = [];
                    var userStorydata = [];
                    var averageStorydata = [];
                    if (response.averageStoryPoints != null) {
                        $.each(response.averageStoryPoints, function (i, value) {
                            userStorylabels.push(value.iterationName);
                            averageStorydata.push(value.avgStoryPoint)
                            userStorydata.push(value.storyCount)
                        });
                       
                    }

                    var datapoints = [];
                   averageStoryPoints(userStorylabels, userStorydata, averageStorydata);
                    if (response.lstiterationBurnups != null) {
                        for (var i = 0; i < response.lstiterationBurnups.length; i++) {
                            datapoints.push(response.lstiterationBurnups[i].zeroDays);
                            datapoints.push(response.lstiterationBurnups[i].twoDays);
                            datapoints.push(response.lstiterationBurnups[i].fourDays);
                            datapoints.push(response.lstiterationBurnups[i].sixDays);
                            datapoints.push(response.lstiterationBurnups[i].eightDays);
                            datapoints.push(response.lstiterationBurnups[i].tenDays);
                        }
                        Burndownchart(null, datapoints);
                    }
                  

                    //document.getElementById("burnchartId").hidden = false;
                }
                else {
                    alert('No Record Found!');
                    var table = $('#example').DataTable();
                    table.clear().draw();
                    selectGauge3.set(0);
                    $("#divPredictability").text('0 %')

                    selectGauge4.set(0);
                    $("#divSprintLoad").text('0 %')

                    LoadoneSprintLookahead(null);
                    averageStoryPoints(null, null, null);
                    Burndownchart(null, null);
                }
            },
            error: function (response) {
                // debugger;
                console.log("error");
                console.log(response.data);
            }
        });
    });
});