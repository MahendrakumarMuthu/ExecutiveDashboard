$(function () {
    'use strict'
  
    var riskDetails = JSON.parse($('#riskDetails').val());
    
   
    // Bar charts
    $('.peity-donut').peity('donut');

    // Donut Chart
    var datapie = {
        labels: ['High', 'Medium', 'Low'],
        datasets: [{
            data: [riskDetails[0].actualCount, riskDetails[2].actualCount, riskDetails[1].actualCount],
            backgroundColor: ['#dc3545', '#FFBF00', '#3bb001']
        }]
    };

    var optionpie = {
        maintainAspectRatio: false,
        responsive: true,
        legend: {
            display: false,
        },
        animation: {
            animateScale: true,
            animateRotate: true
        }
    };

    // For a doughnut chart
    var ctxpie = document.getElementById('chartDonut');
    var myPieChart6 = new Chart(ctxpie, {
        type: 'doughnut',
        data: datapie,
        options: optionpie
    });

});