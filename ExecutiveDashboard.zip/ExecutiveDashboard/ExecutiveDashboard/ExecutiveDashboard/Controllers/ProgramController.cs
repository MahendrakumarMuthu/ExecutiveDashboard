﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ExecutiveDashboard.UI.Models;
using System.Net.Http;
using System.Collections;
using Newtonsoft.Json;
using Microsoft.Extensions.Configuration;

namespace ExecutiveDashboard.UI.Controllers
{
    public class ProgramController : Controller
    {
        private readonly IConfiguration _config;
        private readonly string ApiBaseUrl="";

        public ProgramController(IConfiguration config)
        {
            _config = config;
            ApiBaseUrl = _config.GetValue<string>("ApiSettings:ApiBaseUrl");
        }
        public IActionResult Index(GetEpicDetailsRequest request)
        {
            ReleaseEpicViewModel result = new ReleaseEpicViewModel();
            var lstReleaseData = GetReleaseDetails();
            var lstEpicDetails = GetEpicDetails(request.ProgramDetailsId);

            if (lstReleaseData != null && lstEpicDetails != null)
            {
                result.releaseDetails = lstReleaseData;
                result.epicDetails = lstEpicDetails;
            }
        
            ViewBag.ProgramName = request.ProgramName;
            ViewBag.ProgramId = request.ProgramDetailsId;
            return View(result);
        }
        public IActionResult GetEpicWiseInformation(EpicwiseInformationRequest request)
        {
            EpicWiseInformationResponseViewModel resultDetails = new EpicWiseInformationResponseViewModel();
            try
            {

                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri(ApiBaseUrl);


                    var responseTask = client.GetAsync(string.Format("epicinfo/{0}/{1}", request.EpicId, request.ReleaseId));

                    //  var responseTask = client.GetAsync("programinfo");
                    responseTask.Wait();

                    var result = responseTask.Result;
                    if (result.IsSuccessStatusCode)
                    {
                        var readTask = result.Content.ReadAsAsync<EpicwiseInformationResponse>();
                        readTask.Wait();
                        if (readTask != null)
                        {
                            resultDetails.averageStoryPoints = readTask.Result.averageStoryPoints;
                            resultDetails.predictability = readTask.Result.predictability;
                            resultDetails.sprintLookAhead = readTask.Result.sprintLookAhead;
                            resultDetails.sprintPercentage = readTask.Result.sprintPercentage;
                            resultDetails.storyTrends = readTask.Result.storyTrends;
                            var IterationList = resultDetails.storyTrends.GroupBy(x => new { IterationName = x.iterationName, SprintStartDate = x.iterationStartDate, SprintEndDate = x.iterationEndDate, Velocity = x.completedVelocity,x.velocityPercentage })
                            .Select(tt => new StoryTrends { iterationName = tt.Key.IterationName, iterationStartDate = tt.Key.SprintStartDate, iterationEndDate = tt.Key.SprintEndDate, completedVelocity = tt.Key.Velocity,velocityPercentage=tt.Key.velocityPercentage }).ToList();
                            resultDetails.lstIteration = IterationList;

                            resultDetails.risks = readTask.Result.risks;
                            resultDetails.riskSeverities = readTask.Result.riskSeverities;
                            ViewBag.IterationList = IterationList;


                        }
                    }
                    else //web api sent error response 
                    {
                        //log response status here..

                        resultDetails = null;

                        ModelState.AddModelError(string.Empty, "Server error. Please contact administrator.");
                    }

                  
                }



            }
            catch (Exception ex)
            {

            }
            return Json(resultDetails);
        }

        public List<ReleaseDetails> GetReleaseDetails()
        {
            List<ReleaseDetails> releaseDetails = new List<ReleaseDetails>();
            try
            {

                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri(ApiBaseUrl);
                    //HTTP GET
                    var responseTask = client.GetAsync("release");
                    responseTask.Wait();

                    var result = responseTask.Result;

                    if (result.IsSuccessStatusCode)
                    {
                        var readTask = result.Content.ReadAsAsync<List<ReleaseDetails>>();
                        readTask.Wait();
                        if (readTask.Result != null)
                        {
                            releaseDetails = readTask.Result;
                        }
                        else
                        {
                            releaseDetails = null;

                            ModelState.AddModelError(string.Empty, "Server error. Please contact administrator.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
            }

            return releaseDetails;
        }
        public List<EpicDetails> GetEpicDetails(int ProgramDetailsId)
        {
            List<EpicDetails> releaseDetails = new List<EpicDetails>();
            try
            {

                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri(ApiBaseUrl);
                    //HTTP GET
                    var responseTask = client.GetAsync("Epic");
                    responseTask.Wait();

                    var result = responseTask.Result;

                    if (result.IsSuccessStatusCode)
                    {
                        var readTask = result.Content.ReadAsAsync<List<EpicDetails>>();
                        readTask.Wait();
                        if (readTask.Result != null)
                        {
                            var epicDetailsAll = readTask.Result;
                            if (ProgramDetailsId > 0)
                                releaseDetails = epicDetailsAll.Where(tt => tt.ProgramDetailId == ProgramDetailsId).ToList();
                            else

                                releaseDetails = epicDetailsAll;
                        }
                        else
                        {
                            releaseDetails = null;

                            ModelState.AddModelError(string.Empty, "Server error. Please contact administrator.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
            }

            return releaseDetails;
        }
       
    }
}
