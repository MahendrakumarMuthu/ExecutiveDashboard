﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ExecutiveDashboard.UI.Models;
using System.Net.Http;
using Microsoft.Extensions.Configuration;

namespace ExecutiveDashboard.UI.Controllers
{
    public class TeamController : Controller
    {
        private readonly IConfiguration _config;
        private readonly string ApiBaseUrl = "";

        public TeamController(IConfiguration config)
        {
            _config = config;
            ApiBaseUrl = _config.GetValue<string>("ApiSettings:ApiBaseUrl");
        }
        public IActionResult Index(GetEpicDetailsRequest request)
        {

            ViewBag.ProgramDetailId = request.ProgramDetailsId;
            ViewBag.ProgramName = request.ProgramName;
            ReleaseTeamViewModel resultDetails = new ReleaseTeamViewModel();
            
            var lstReleaseData = GetReleaseDetails();
            var lstTeamData = GetTeamDetails();
            if (lstReleaseData != null)
            {
                resultDetails.releaseDetails = lstReleaseData;
            }
            if (lstReleaseData != null)
            {
                resultDetails.teamDetails = lstTeamData;
            }

            return View(resultDetails);
        }


        public IActionResult TeamWiseInformation(TeamWiseInformationRequest request)
        {
            EpicWiseInformationResponseViewModel resultDetails = new EpicWiseInformationResponseViewModel();
            try
            {

                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri(ApiBaseUrl);


                    var responseTask = client.GetAsync(string.Format("teaminfo/{0}/{1}", request.TeamId, request.ReleaseId));

                    //  var responseTask = client.GetAsync("programinfo");
                    responseTask.Wait();

                    var result = responseTask.Result;
                    if (result.IsSuccessStatusCode)
                    {
                        var readTask = result.Content.ReadAsAsync<TeamWiseInformationResponse>();
                        readTask.Wait();
                        if (readTask != null)
                        {
                            resultDetails.averageStoryPoints = readTask.Result.averageStoryPoints;
                            resultDetails.predictability = readTask.Result.predictability;
                            resultDetails.sprintLookAhead = readTask.Result.sprintLookAhead;
                            resultDetails.sprintPercentage = readTask.Result.sprintPercentage;
                            resultDetails.storyTrends = readTask.Result.storyTrends;
                            resultDetails.lstiterationBurnups = readTask.Result.iterationBurnup;
                            var IterationList = resultDetails.storyTrends.GroupBy(x => new { IterationName = x.iterationName, SprintStartDate = x.iterationStartDate, SprintEndDate = x.iterationEndDate, Velocity = x.completedVelocity,x.velocityPercentage })
                            .Select(tt => new StoryTrends { iterationName = tt.Key.IterationName, iterationStartDate = tt.Key.SprintStartDate, iterationEndDate = tt.Key.SprintEndDate, completedVelocity = tt.Key.Velocity,velocityPercentage=tt.Key.velocityPercentage }).ToList();
                            resultDetails.lstIteration = IterationList;


                            ViewBag.IterationList = IterationList;


                        }
                    }
                    else //web api sent error response 
                    {
                        //log response status here..

                        resultDetails = null;

                        ModelState.AddModelError(string.Empty, "Server error. Please contact administrator.");
                    }


                }



            }
            catch (Exception ex)
            {

            }
            return Json(resultDetails);
        }

        public List<ReleaseDetails> GetReleaseDetails()
        {
            List<ReleaseDetails> releaseDetails = new List<ReleaseDetails>();
            try
            {

                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri(ApiBaseUrl);
                    //HTTP GET
                    var responseTask = client.GetAsync("release");
                    responseTask.Wait();

                    var result = responseTask.Result;

                    if (result.IsSuccessStatusCode)
                    {
                        var readTask = result.Content.ReadAsAsync<List<ReleaseDetails>>();
                        readTask.Wait();
                        if (readTask.Result != null)
                        {
                            releaseDetails = readTask.Result;
                        }
                        else
                        {
                            releaseDetails = null;

                            ModelState.AddModelError(string.Empty, "Server error. Please contact administrator.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
            }

            return releaseDetails;
        }

        public List<TeamDetails> GetTeamDetails()
        {
            List<TeamDetails> teamDetails = new List<TeamDetails>();
            try
            {

                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri(ApiBaseUrl);
                    //HTTP GET
                    var responseTask = client.GetAsync("team");
                    responseTask.Wait();

                    var result = responseTask.Result;

                    if (result.IsSuccessStatusCode)
                    {
                        var readTask = result.Content.ReadAsAsync<List<TeamDetails>>();
                        readTask.Wait();
                        if (readTask.Result != null)
                        {
                            teamDetails = readTask.Result;
                        }
                        else
                        {
                            teamDetails = null;

                            ModelState.AddModelError(string.Empty, "Server error. Please contact administrator.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
            }

            return teamDetails;
        }

    }
}
