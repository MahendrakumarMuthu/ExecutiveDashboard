﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ExecutiveDashboard.UI.Models;
using System.Net.Http;
using Newtonsoft.Json;
using Microsoft.Extensions.Configuration;

namespace ExecutiveDashboard.UI.Controllers
{
    public class HomeController : Controller
    {
        private readonly IConfiguration _config;
        private readonly string ApiBaseUrl = "";

        public HomeController(IConfiguration config)
        {
            _config = config;
            ApiBaseUrl = _config.GetValue<string>("ApiSettings:ApiBaseUrl");
        }
        public ActionResult Index()
        {


            ProgramWiseInformation resultDetails = new ProgramWiseInformation();

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(ApiBaseUrl);
                //HTTP GET
                var responseTask = client.GetAsync("programinfo");
                responseTask.Wait();

                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsAsync<ProgramWiseInformation>();
                    readTask.Wait();
                    if (readTask.Result != null)
                    {
                        resultDetails.featureDetails = readTask.Result.featureDetails;
                        resultDetails.programInformation = readTask.Result.programInformation;
                        resultDetails.riskDetails = readTask.Result.riskDetails;
                        resultDetails.riskStatusDetails = readTask.Result.riskStatusDetails;
                        ViewBag.riskStatusDetails = JsonConvert.SerializeObject(readTask.Result.riskStatusDetails);
                    }
                   
                }
                else //web api sent error response
                {
                    //log response status here..

                    resultDetails = null;

                    ModelState.AddModelError(string.Empty, "Server error. Please contact administrator.");
                }


            }

            return View(resultDetails);
        }
    }
}
