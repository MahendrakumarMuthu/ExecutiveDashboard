﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ExecutiveDashboard.UI.Models
{
    public class IterationBurnup
    {
        public string zeroDays { get; set; }
        public string twoDays { get; set; }
        public string fourDays { get; set; }
        public string sixDays { get; set; }
        public string eightDays { get; set; }
        public string tenDays { get; set; }
        public int completedPoints { get; set; }

    }
}
