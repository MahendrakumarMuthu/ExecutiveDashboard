﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ExecutiveDashboard.UI.Models
{
    public class FeatureDetails
    {
        public string ProgramName { get; set; }
        public string FeatureName { get; set; }
        public DateTime featurStartDate { get; set; }
        public DateTime FeatureEndDate { get; set; }
        public DateTime ReleaseStartDate{get;set;}
        public DateTime ReleaseEndDate { get; set; }
        public string ReleaseName { get; set; }
        public string ReleaseNumber { get; set; }


    }
}
