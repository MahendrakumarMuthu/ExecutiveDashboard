﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ExecutiveDashboard.UI.Models
{
    public class GetEpicDetailsRequest
    {
        public int ProgramDetailsId { get; set; }

        public string ProgramName { get; set; }
    }
}
