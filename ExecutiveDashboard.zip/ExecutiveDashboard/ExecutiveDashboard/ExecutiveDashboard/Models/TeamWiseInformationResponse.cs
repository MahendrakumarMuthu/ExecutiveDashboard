﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ExecutiveDashboard.UI.Models
{
    public class TeamWiseInformationResponse
    {
        public decimal predictability { get; set; }
        public decimal sprintPercentage { get; set; }
        public List<StoryTrends> storyTrends { get; set; }
        public List<AverageStoryPoints> averageStoryPoints { get; set; }
        public List<sprintLookAhead> sprintLookAhead { get; set; }
        public List<StoryTrends> lstIteration { get; set; }
        public List<IterationBurnup> iterationBurnup { get; set; }

    }
}
