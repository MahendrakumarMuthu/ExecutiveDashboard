﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ExecutiveDashboard.UI.Models
{
    public class RiskDetails
    {
        public int riskId { get; set; }
        public string comment { get; set; }

       
    }
}
