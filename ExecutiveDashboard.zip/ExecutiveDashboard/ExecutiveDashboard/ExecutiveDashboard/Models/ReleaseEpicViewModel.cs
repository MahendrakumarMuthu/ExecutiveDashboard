﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ExecutiveDashboard.UI.Models
{
    public class ReleaseEpicViewModel
    {
        public List<ReleaseDetails> releaseDetails { get; set; }
        public List<EpicDetails> epicDetails { get; set; }
    }
}
