﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ExecutiveDashboard.UI.Models
{
    public class EpicWiseInformationResponseViewModel
    {
        public decimal predictability { get; set; }
        public decimal sprintPercentage { get; set; }
        public List<StoryTrends> storyTrends { get; set; }
        public List<AverageStoryPoints> averageStoryPoints { get; set; }
        public List<sprintLookAhead> sprintLookAhead { get; set; }
        public List<StoryTrends> lstIteration { get; set; }
        public List<StoryTrends> lstIterationOnly { get; set; }
        public List<RiskDetails> risks { get; set; }
        public List<RiskStatusDetails> riskSeverities { get; set; }
        public List<IterationBurnup> lstiterationBurnups { get; set; }
    }
}
