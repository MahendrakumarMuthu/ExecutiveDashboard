﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ExecutiveDashboard.UI.Models
{
    public class EpicwiseInformationResponse
    {
        public decimal predictability { get; set; }
        public decimal sprintPercentage { get; set; }
        public List<StoryTrends> storyTrends { get; set; }
        public List<AverageStoryPoints> averageStoryPoints { get; set; }
        public List<sprintLookAhead> sprintLookAhead { get; set; }
        public List<StoryTrends> lstIteration { get; set; }
        public List<RiskDetails> risks { get; set; }
        public List<RiskStatusDetails> riskSeverities { get; set; }
    }

    public class StoryTrends
    {
        public int teamID { get; set; }
        public string teamName { get; set; }
        public string iterationName { get;set;}
        public DateTime iterationStartDate { get; set; }
        public DateTime iterationEndDate { get; set; }
        public decimal plannedVelocity { get; set; }
        public decimal actualVelocity { get; set; }
        public decimal completedVelocity { get; set; }
        public decimal velocityPercentage { get; set; }
        public string userStoryNumber { get; set; }
        public string userStoryName { get; set; }
        public string description { get; set; }
        public int planEstimate { get; set; }


    }

    public class AverageStoryPoints
    {
        public string iterationName { get; set; }
        public decimal avgStoryPoint { get; set; }
        public decimal StoryCount { get; set; }
    }

    public class sprintLookAhead
    {
        public string iterationName { get; set; }
        public int needDefintionCount { get; set; }
        public int definedCount { get; set; }
       
    }


}
