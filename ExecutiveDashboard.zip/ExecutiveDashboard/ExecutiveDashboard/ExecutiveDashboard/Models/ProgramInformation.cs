﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ExecutiveDashboard.UI.Models
{
    public class ProgramInformation
    {
        public int ProgramDetailId { get; set; }
        public string ProgramName { get; set; }
        public float Percentage { get; set; }
    }
}
