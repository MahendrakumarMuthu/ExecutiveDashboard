﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ExecutiveDashboard.UI.Models
{
    public class ReleaseTeamViewModel
    {
        public List<ReleaseDetails> releaseDetails { get; set; }
        public List<TeamDetails> teamDetails { get; set; }
    }
}
