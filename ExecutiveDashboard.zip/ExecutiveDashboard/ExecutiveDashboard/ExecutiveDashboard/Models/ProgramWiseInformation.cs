﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ExecutiveDashboard.UI.Models
{
    public class ProgramWiseInformation
    {
        public List<ProgramInformation> programInformation { get; set; }
        public List<FeatureDetails> featureDetails { get; set; }
        public List<RiskDetails> riskDetails { get; set; }
       public List<RiskStatusDetails> riskStatusDetails { get; set; }

    }
}
