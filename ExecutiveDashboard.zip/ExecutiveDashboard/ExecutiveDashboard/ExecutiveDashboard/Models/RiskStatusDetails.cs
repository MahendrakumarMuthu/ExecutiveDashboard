﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ExecutiveDashboard.UI.Models
{
    public class RiskStatusDetails
    {
        public string StatusName {get;set;}
        public int actualCount { get; set; }
        public float Percentage { get; set; }
    }
}
